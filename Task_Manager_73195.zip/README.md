# Task Manager – Team Project (IT)

Student ID: **73195**

## Overview

This project is a simple Task Manager for the Vistula Team Project assignment. It uses:
- HTML, CSS, and JavaScript
- Git / GitHub
- GitHub Pages
- Supabase PostgreSQL and REST API

## Files

- `index.html` – main Task Manager page
- `app.js` – CRUD logic using the Supabase REST API
- `style.css` – styling
- `config.json` – public Supabase configuration
- `contribution.html` – contributor page
- `contribution.json` – contributor ID data
- `.gitignore` – ignores local editor and system files

## Required setup

Before deployment, replace the placeholder values in `config.json` with your own public Supabase details:

- `supabaseUrl`
- `supabasePublishableKey`

The table name must remain `tasks`.

## Features

- Display all tasks
- Add a new task
- Edit an existing task
- Mark a task as completed or incomplete
- Delete a task
- Show contributor ID from `contribution.json`

## Notes

This package is a code starter and submission-ready project structure, but it still needs:
1. Your own GitHub repository and GitHub Pages deployment.
2. Your own Supabase project and public configuration.
3. The required merged Pull Requests with another student.

## Expected URLs

- Main app: `https://USERNAME.github.io/vistula-task-manager/`
- Contributor page: `https://USERNAME.github.io/vistula-task-manager/contribution.html`
- Contributor JSON: `https://USERNAME.github.io/vistula-task-manager/contribution.json`
